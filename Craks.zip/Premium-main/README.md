# Premium

**Ini Adalah Script Untuk Crack Akun Instagram, Untuk Cara Menggunakannya Bisa Lihat Di** https://youtu.be/u17ZQgSs3aY

# Screenshot
![Screenshot_2022-05-26-10-53-13-46_84d3000e3f4017145260f7618db1d683](https://user-images.githubusercontent.com/65714340/170805786-10861f3d-e9ba-480d-b720-03112bb4ace5.png)

# Perintah :
    $ pkg update && pkg upgrade
    $ pkg install git
    $ pkg install python
    $ pip install requests
    $ pip install futures
    $ git clone https://github.com/RozhakXD/Premium
    $ cd Premium
    $ python Prem.py
# Cara Update :
    $ rm -rf Premium
    $ git clone https://github.com/RozhakXD/Premium
    $ cd Premium
    $ python Prem.py
